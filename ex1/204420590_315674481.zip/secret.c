#include <stdio.h>
int main()
{
	printf("Please enter password\n");
	char password[1000];
	scanf ("%s\n",password);
	printf("Doing super secret stuff\n");
	while (1); 
}
